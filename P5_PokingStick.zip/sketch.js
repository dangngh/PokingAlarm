let url = 'https://io.adafruit.com/api/v2/dangngh/feeds/button';
let counter = 0;
let serial;
let turn=0;

function setup() {
    createCanvas(255, 255);
   serial = new p5.SerialPort();

  // serial port to use - you'll need to change this
  serial.open('COM4');
}

function draw() {
    fill(255, 10);
    rect(0, 0, width, height);
    if (counter % 80 == 0) {
        getData();
    }
    counter++;
}

function getData() {
    let data;
  
    httpGet(url, 'json', function (response) {
        data = response.last_value;
 turn = data * 255
   serial.write(turn);
        console.log(turn);
    });
}